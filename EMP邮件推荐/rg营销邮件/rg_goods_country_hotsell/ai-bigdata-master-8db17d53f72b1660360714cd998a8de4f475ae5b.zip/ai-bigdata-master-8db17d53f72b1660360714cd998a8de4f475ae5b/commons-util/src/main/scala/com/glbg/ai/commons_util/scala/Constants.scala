package com.glbg.ai.commons_util.scala

object Constants {

  val KEY_SEPARATE = "_"
  val ARGS_SEPARATE = ","

}
